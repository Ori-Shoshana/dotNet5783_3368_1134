﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Stage0
//{
//    partial class Program
//    {
//        static partial void Welcome3368()
//            {
//            Console.WriteLine( " I am also here!");
//            }
//    }
//}
