﻿
namespace DO;
/// <summary>
/// struct enums that contains enum of the product categories
/// </summary>
public struct Enums
{
    public enum productCategory {  Phone, Laptop, Mouse, Keybord, Hadphones };
}
