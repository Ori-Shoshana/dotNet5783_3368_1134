﻿
using DO;
namespace DalApi;
/// <summary>
/// order inherits from interface ICrud
/// </summary>
public interface IOrder : ICrud<Order>
{
}
