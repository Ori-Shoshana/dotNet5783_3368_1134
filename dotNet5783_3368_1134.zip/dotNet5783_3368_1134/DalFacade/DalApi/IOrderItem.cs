﻿
using DO;
namespace DalApi;
/// <summary>
/// order item inherits from interface ICrud
/// </summary>
public interface IOrderItem : ICrud<OrderItem>
{
}
