﻿
using DO;
namespace DalApi;
/// <summary>
/// product inherits from interface ICrud
/// </summary>
public interface IProduct : ICrud<Product>
{
}